let amigos = [];

// Agregar nombre a la lista
function agregarAmigo() {
    let input = document.getElementById("nombreAmigo");
    let nombre = input.value.trim();

    if (nombre === "") {
        alert("Por favor ingresa un nombre válido.");
        return;
    }

    // Validar que no se repita
    if (amigos.includes(nombre)) {
        alert("Ese nombre ya fue agregado.");
        input.value = "";
        return;
    }

    amigos.push(nombre);
    actualizarLista();
    input.value = "";
}

// Mostrar lista de amigos
function actualizarLista() {
    let lista = document.getElementById("listaAmigos");
    lista.innerHTML = "";

    for (let amigo of amigos) {
        let li = document.createElement("li");
        li.textContent = amigo;
        lista.appendChild(li);
    }
}

// Sortear un amigo aleatoriamente SIN repetir
function sortearAmigo() {
    if (amigos.length === 0) {
        document.getElementById("resultado").textContent =
            "Todos los nombres fueron sorteados.";
        return;
    }

    let indiceAleatorio = Math.floor(Math.random() * amigos.length);
    let amigoSorteado = amigos[indiceAleatorio];

    // Mostrar el resultado
    document.getElementById("resultado").textContent =
        `El amigo sorteado es: ${amigoSorteado}`;

    // Eliminar el amigo sorteado de la lista para que no se repita
    amigos.splice(indiceAleatorio, 1);
    actualizarLista();
}